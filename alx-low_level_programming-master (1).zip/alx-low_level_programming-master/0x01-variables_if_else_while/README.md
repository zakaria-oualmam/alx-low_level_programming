Project completed during Full Stack Software Engineering studies at Western Brothers. The objective is to learn about arithmetic operators, relational operators, boolean operators, comments, declaring variables, and loops in C language.
Technologies
Scripts written in Bash 4.3.11(1)
C files are compiled using gcc 4.8.4
C files are written in compliance with the C90 standard
Tested on Ubuntu 14.04 LTS
