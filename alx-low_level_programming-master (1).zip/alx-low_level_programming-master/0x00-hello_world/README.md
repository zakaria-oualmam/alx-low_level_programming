# ALX School - 0x00-hello_world
Compiling very simple programs with gcc. Learning the steps of compilation.
## New commands / functions used:
``gcc, printf, puts, putchar``
## Helpful Links
